import express from "express";
import axios from "axios";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import os from "os";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;
function isJetsonHost() {
  try {
    if (os.platform() !== "linux") return false;
    if (fs.existsSync("/etc/nv_tegra_release")) return true;
    try {
      const m = fs.readFileSync("/proc/device-tree/model", "utf8").toLowerCase();
      if (m.includes("jetson")) return true;
    } catch {}
  } catch {}
  return false;
}
const JETSON_ONLY = String(process.env.JETSON_ONLY || "false").toLowerCase() === "true";
if (JETSON_ONLY && !isJetsonHost()) {
  console.error("JETSON_ONLY=true: refusing to start on non-Jetson host");
  process.exit(1);
}
const DEEPSTREAM_URL = process.env.DEEPSTREAM_URL || "http://localhost:8080/api/v1";
let messages = [];

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/stream", async (req, res) => {
  try {
    const r = await axios.post(`${DEEPSTREAM_URL}/stream`, req.body);
    res.status(r.status).json(r.data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete("/api/stream/:id", async (req, res) => {
  try {
    const r = await axios.delete(`${DEEPSTREAM_URL}/stream/${req.params.id}`);
    res.status(r.status).json(r.data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put("/api/infer", async (req, res) => {
  try {
    const r = await axios.put(`${DEEPSTREAM_URL}/infer`, req.body);
    res.status(r.status).json(r.data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/roi", async (req, res) => {
  try {
    const r = await axios.post(`${DEEPSTREAM_URL}/roi`, req.body);
    res.status(r.status).json(r.data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/health", async (_req, res) => {
  try {
    const r = await axios.get(`${DEEPSTREAM_URL}/health`);
    res.json({ status: "connected", deepstream: r.data });
  } catch (e) {
    res.status(503).json({ status: "disconnected", error: "Cannot reach DeepStream" });
  }
});

app.post("/api/message", (req, res) => {
  const t = (req.body && req.body.text) || "";
  if (!t) return res.status(400).json({ error: "text required" });
  const m = { text: t, ts: Date.now() };
  messages.push(m);
  if (messages.length > 500) messages.shift();
  res.json({ ok: true });
});

app.get("/api/message", (_req, res) => {
  res.json({ messages });
});

app.delete("/api/message", (_req, res) => {
  messages = [];
  res.json({ ok: true });
});

import http from "http";

function dockerRequest(method, path, body) {
  return new Promise((resolve) => {
    const opts = { socketPath: "/var/run/docker.sock", path, method, headers: {} };
    let payload = null;
    if (body) {
      payload = Buffer.from(JSON.stringify(body));
      opts.headers["Content-Type"] = "application/json";
      opts.headers["Content-Length"] = String(payload.length);
    }
    const req = http.request(opts, (resp) => {
      let data = "";
      resp.on("data", (c) => { data += c; });
      resp.on("end", () => { resolve({ statusCode: resp.statusCode || 0, body: data }); });
    });
    req.on("error", (e) => { resolve({ statusCode: 0, body: String(e) }); });
    if (payload) req.write(payload);
    req.end();
  });
}

const DS_IMAGE = process.env.DEEPSTREAM_IMAGE || "nvcr.io/nvidia/deepstream-l4t:6.0.1-samples";
const SNAP_DIR = process.env.SNAP_DIR || "/data/snapshots";
const CONFIGS_DIR = process.env.CONFIGS_DIR || "/app/configs/";
app.use("/snapshots", express.static(SNAP_DIR));

app.post("/api/snapshot/start", async (req, res) => {
  let uri = (req.body && req.body.uri) || "";
  const rate = Number((req.body && req.body.rate) || 1);
  if (!uri) return res.status(400).json({ error: "uri required" });
  await fs.promises.mkdir(SNAP_DIR, { recursive: true });
  if (uri.startsWith("/media/")) { uri = "/data/videos/" + uri.slice(7); }
  const isRtsp = uri.startsWith("rtsp://");
  const ext = (() => { try { return (path.extname(uri) || "").toLowerCase(); } catch { return ""; } })();
  const cmds = [];
  if (isRtsp) {
    cmds.push(`gst-launch-1.0 rtspsrc location='${uri}' latency=200 ! rtph264depay ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw,format=I420 ! videorate drop-only=true max-rate=${rate} ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg`);
  } else {
    cmds.push(`gst-launch-1.0 -vv playbin uri='file://${uri}' video-sink=\"videoconvert ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg\" audio-sink=fakesink`);
    cmds.push(`gst-launch-1.0 uridecodebin uri='file://${uri}' ! videoconvert ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg`);
    cmds.push(`gst-launch-1.0 filesrc location='${uri}' ! decodebin ! videoconvert ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg`);
    cmds.push(`gst-launch-1.0 filesrc location='${uri}' ! qtdemux ! h264parse ! nvv4l2decoder ! nvvidconv ! video/x-raw,format=I420 ! videorate drop-only=true max-rate=${rate} ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg`);
    cmds.push(`gst-launch-1.0 filesrc location='${uri}' ! qtdemux ! h265parse ! nvv4l2decoder ! nvvidconv ! video/x-raw,format=I420 ! videorate drop-only=true max-rate=${rate} ! jpegenc ! multifilesink location=${SNAP_DIR}/snap_%05d.jpg`);
  }
  await dockerRequest("DELETE", "/containers/ds_snapshot?force=true");
  const binds = [`${SNAP_DIR}:${SNAP_DIR}`];
  if (!isRtsp) { try { const dir = path.dirname(uri); binds.push(`${dir}:${dir}`); } catch {} }
  let ok = false, used = "";
  for (const c of cmds) {
    const body = { Image: DS_IMAGE, Entrypoint: ["bash"], Cmd: ["-lc", c], HostConfig: { NetworkMode: "host", Runtime: "nvidia", Binds: binds } };
    await dockerRequest("DELETE", "/containers/ds_snapshot?force=true");
    const created = await dockerRequest("POST", "/containers/create?name=ds_snapshot", body);
    if (created.statusCode < 200 || created.statusCode >= 300) continue;
    const start = await dockerRequest("POST", "/containers/ds_snapshot/start");
    if (start.statusCode >= 200 && start.statusCode < 300) { ok = true; used = c; break; }
  }
  if (!ok) return res.status(500).json({ error: "failed to start snapshot" });
  res.json({ ok: true, pipeline: used });
});

app.get("/api/snapshot/logs", async (_req, res) => {
  const logs = await dockerRequest("GET", "/containers/ds_snapshot/logs?stdout=1&stderr=1&tail=200");
  res.type("text/plain").send(logs.body || "");
});

app.post("/api/snapshot/stop", async (_req, res) => {
  await dockerRequest("POST", "/containers/ds_snapshot/stop");
  await dockerRequest("DELETE", "/containers/ds_snapshot?force=true");
  res.json({ ok: true });
});

app.delete("/api/snapshot/clear", async (_req, res) => {
  try {
    await fs.promises.mkdir(SNAP_DIR, { recursive: true });
    const files = await fs.promises.readdir(SNAP_DIR);
    let deleted = 0;
    await Promise.all(files.map(async (f) => {
      if (f.toLowerCase().endsWith(".jpg")) {
        try { await fs.promises.unlink(path.join(SNAP_DIR, f)); deleted++; } catch {}
      }
    }));
    res.json({ ok: true, deleted });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/hls/start", async (req, res) => {
  let uri = (req.body && req.body.uri) || "";
  const target = "/app/public/video/out.m3u8";
  if (!uri) return res.status(400).json({ error: "uri required" });
  if (uri.startsWith("/media/")) { uri = "/data/videos/" + uri.slice(7); }
  const isRtsp = uri.startsWith("rtsp://");
  const binds = ["/data/hls:/app/public/video"];
  if (!isRtsp) { try { const dir = path.dirname(uri); binds.push(`${dir}:${dir}`); } catch {}
  }
  const baseSink = `hlssink max-files=5 target-duration=2 playlist-location=${target} location=/app/public/video/out_%05d.ts`;
  await dockerRequest("DELETE", "/containers/ds_hls?force=true");
  let ok = false, used = "";
  const ffimg = "lscr.io/linuxserver/ffmpeg:latest";
  const ffCmd = isRtsp
    ? ["-hide_banner","-loglevel","warning","-rtsp_transport","tcp","-i", uri, "-c:v","copy","-c:a","aac","-f","hls","-hls_time","2","-hls_list_size","5","-hls_flags","delete_segments", target]
    : ["-hide_banner","-loglevel","warning","-re","-i", uri, "-c:v","copy","-c:a","aac","-f","hls","-hls_time","2","-hls_list_size","5","-hls_flags","delete_segments", target];
  await dockerRequest("DELETE", "/containers/ds_hls?force=true");
  let created = await dockerRequest("POST", "/containers/create?name=ds_hls", { Image: ffimg, Cmd: ffCmd, HostConfig: { NetworkMode: "host", Binds: binds } });
  if (!(created.statusCode >= 200 && created.statusCode < 300)) {
    await dockerRequest("POST", `/images/create?fromImage=${encodeURIComponent(ffimg)}`);
    await dockerRequest("DELETE", "/containers/ds_hls?force=true");
    created = await dockerRequest("POST", "/containers/create?name=ds_hls", { Image: ffimg, Cmd: ffCmd, HostConfig: { NetworkMode: "host", Binds: binds } });
  }
  if (created.statusCode >= 200 && created.statusCode < 300) {
    const start = await dockerRequest("POST", "/containers/ds_hls/start");
    if (start.statusCode >= 200 && start.statusCode < 300) { ok = true; used = `ffmpeg ${ffCmd.join(" ")}`; }
  }
  if (!ok) {
    const cmds = [];
    if (isRtsp) {
      cmds.push(`gst-launch-1.0 -vv rtspsrc location='${uri}' latency=200 ! rtph264depay ! h264parse config-interval=-1 ! mpegtsmux ! ${baseSink}`);
      cmds.push(`gst-launch-1.0 -vv rtspsrc location='${uri}' latency=200 ! rtph265depay ! h265parse ! mpegtsmux ! ${baseSink}`);
    } else {
      cmds.push(`gst-launch-1.0 -vv filesrc location='${uri}' ! qtdemux ! h264parse config-interval=-1 ! mpegtsmux ! ${baseSink}`);
      cmds.push(`gst-launch-1.0 -vv filesrc location='${uri}' ! qtdemux ! h265parse ! mpegtsmux ! ${baseSink}`);
      cmds.push(`gst-launch-1.0 -vv filesrc location='${uri}' ! matroskademux ! h264parse config-interval=-1 ! mpegtsmux ! ${baseSink}`);
    }
    for (const c of cmds) {
      const body = { Image: DS_IMAGE, Entrypoint: ["bash"], Cmd: ["-lc", c], HostConfig: { NetworkMode: "host", Runtime: "nvidia", Binds: binds } };
      await dockerRequest("DELETE", "/containers/ds_hls?force=true");
      const created2 = await dockerRequest("POST", "/containers/create?name=ds_hls", body);
      if (created2.statusCode < 200 || created2.statusCode >= 300) continue;
      const start2 = await dockerRequest("POST", "/containers/ds_hls/start");
      if (start2.statusCode >= 200 && start2.statusCode < 300) { ok = true; used = c; break; }
    }
  }
  if (!ok) {
    const ffimg = "jrottenberg/ffmpeg:4.4-alpine";
    const ffCmd = isRtsp
      ? ["-hide_banner","-loglevel","warning","-rtsp_transport","tcp","-i", uri, "-c:v","copy","-c:a","aac","-f","hls","-hls_time","2","-hls_list_size","5","-hls_flags","delete_segments", target]
      : ["-hide_banner","-loglevel","warning","-re","-i", uri, "-c:v","copy","-c:a","aac","-f","hls","-hls_time","2","-hls_list_size","5","-hls_flags","delete_segments", target];
    await dockerRequest("DELETE", "/containers/ds_hls?force=true");
    let created = await dockerRequest("POST", "/containers/create?name=ds_hls", { Image: ffimg, Cmd: ffCmd, HostConfig: { NetworkMode: "host", Binds: binds } });
    if (!(created.statusCode >= 200 && created.statusCode < 300)) {
      await dockerRequest("POST", `/images/create?fromImage=${encodeURIComponent(ffimg)}`);
      await dockerRequest("DELETE", "/containers/ds_hls?force=true");
      created = await dockerRequest("POST", "/containers/create?name=ds_hls", { Image: ffimg, Cmd: ffCmd, HostConfig: { NetworkMode: "host", Binds: binds } });
    }
    if (created.statusCode >= 200 && created.statusCode < 300) {
      const start = await dockerRequest("POST", "/containers/ds_hls/start");
      if (start.statusCode >= 200 && start.statusCode < 300) { ok = true; used = `ffmpeg ${ffCmd.join(" ")}`; }
    }
  }
  if (!ok) return res.status(500).json({ error: "failed to start hls" });
  res.json({ ok: true, pipeline: used, playlist: "/video/out.m3u8" });
});

app.post("/api/hls/stop", async (_req, res) => {
  await dockerRequest("POST", "/containers/ds_hls/stop");
  await dockerRequest("DELETE", "/containers/ds_hls?force=true");
  res.json({ ok: true });
});

app.get("/api/hls/logs", async (_req, res) => {
  const logs = await dockerRequest("GET", "/containers/ds_hls/logs?stdout=1&stderr=1&tail=200");
  res.type("text/plain").send(logs.body || "");
});

function toNumber(v) { try { return Number(v) || 0; } catch { return 0; } }

app.get("/api/local-health", async (_req, res) => {
  let snapCount = 0;
  try { const files = await fs.promises.readdir(SNAP_DIR); snapCount = files.filter(f => f.endsWith(".jpg")).length; } catch {}
  const info = await dockerRequest("GET", "/containers/ds_snapshot/json");
  let state = null;
  try { state = JSON.parse(info.body).State || null; } catch {}
  const statsResp = await dockerRequest("GET", "/containers/ds_snapshot/stats?stream=false");
  let cpuPercent = 0, memUsage = 0, memLimit = 0, gpu = null;
  try {
    const s = JSON.parse(statsResp.body);
    const cpuDelta = toNumber(s.cpu_stats && s.cpu_stats.cpu_usage && s.cpu_stats.cpu_usage.total_usage) - toNumber(s.precpu_stats && s.precpu_stats.cpu_usage && s.precpu_stats.cpu_usage.total_usage);
    const sysDelta = toNumber(s.cpu_stats && s.cpu_stats.system_cpu_usage) - toNumber(s.precpu_stats && s.precpu_stats.system_cpu_usage);
    const cpus = (s.cpu_stats && s.cpu_stats.online_cpus) || (s.cpu_stats && s.cpu_stats.cpu_usage && s.cpu_stats.cpu_usage.percpu_usage && s.cpu_stats.cpu_usage.percpu_usage.length) || 1;
    cpuPercent = sysDelta > 0 ? (cpuDelta / sysDelta) * cpus * 100 : 0;
    memUsage = toNumber(s.memory_stats && s.memory_stats.usage);
    memLimit = toNumber(s.memory_stats && s.memory_stats.limit);
    gpu = s.gpu_stats || null;
  } catch {}
  const load = os.loadavg();
  const uptime = os.uptime();
  res.json({ snap: { state, cpuPercent, memUsage, memLimit, gpu, snapCount }, system: { load, uptime } });
});

app.get("/api/snapshot/list", async (req, res) => {
  try {
    const files = await fs.promises.readdir(SNAP_DIR);
    const jpgs = files.filter(f => f.toLowerCase().endsWith(".jpg"));
    const stats = await Promise.all(jpgs.map(async f => {
      const s = await fs.promises.stat(path.join(SNAP_DIR, f));
      return { f, t: s.mtimeMs };
    }));
    stats.sort((a, b) => b.t - a.t);
    const limit = Math.max(1, Math.min(Number(req.query.limit || 20), 100000));
    res.json({ files: stats.slice(0, limit).map(x => x.f) });
  } catch (e) {
    res.json({ files: [] });
  }
});

app.listen(PORT, () => {
  console.log(`Web server running at http://localhost:${PORT}/`);
});

const DS_APP_IMAGE = process.env.DS_APP_IMAGE || DS_IMAGE;
function buildSampleCmd(sample, uris) {
  const base = "/opt/nvidia/deepstream/deepstream-6.0";
  const bins = {
    test1: `${base}/sources/apps/sample_apps/deepstream-test1/deepstream-test1-app`,
    test2: `${base}/sources/apps/sample_apps/deepstream-test2/deepstream-test2-app`,
    test3: `${base}/sources/apps/sample_apps/deepstream-test3/deepstream-test3-app`,
    test5: `${base}/sources/apps/sample_apps/deepstream-test5/deepstream-test5-app`,
    testsr: `${base}/sources/apps/sample_apps/deepstream-testsr/deepstream-testsr-app`,
  };
  const streams = {
    h264: `${base}/samples/streams/sample_720p.h264`,
    h265: `${base}/samples/streams/sample_720p.h265`,
  };
  if (sample === "app_source1") {
    return `cd ${base}/samples/configs/deepstream-app && (deepstream-app -c source1_1080p_dec_infer-resnet_int8.txt || deepstream-app -c source1_1080p_dec_infer-resnet.txt)`;
  }
  if (sample === "app_source30") {
    return `cd ${base}/samples/configs/deepstream-app && (deepstream-app -c source30_1080p_dec_infer-resnet_tiled_display_int8.txt || deepstream-app -c source30_1080p_dec_infer-resnet_tiled_display_fp16.txt)`;
  }
  if (sample === "app_custom_ini") {
    const ini = Array.isArray(uris) && uris.length ? uris[0] : "";
    if (ini.startsWith("/app/configs/")) {
      const dir = path.dirname(ini);
      const file = path.basename(ini);
      return `cd ${dir} && deepstream-app -c ${file}`;
    }
    return `deepstream-app -c ${ini}`;
  }
  const bin = bins[sample] || bins.test1;
  const args = Array.isArray(uris) && uris.length ? uris.map(u => u.startsWith("file://") ? u.replace(/^file:\/\//, "") : u) : [streams.h264];
  const dir = path.dirname(bin);
  const exe = path.basename(bin);
  return `cd ${dir} && ./${exe} ${args.join(" ")}`;
}

app.get("/api/dsapp/samples", (_req, res) => {
  res.json({ samples: [
    { id: "test1", label: "Test1 Single Source" },
    { id: "test2", label: "Test2 Multi Source" },
    { id: "test3", label: "Test3 SGIE" },
    { id: "test5", label: "Test5 Analytics" },
    { id: "testsr", label: "Smart Record" },
    { id: "app_source1", label: "deepstream-app Source1" },
    { id: "app_source30", label: "deepstream-app Source30 Tiled" },
    { id: "app_custom_ini", label: "deepstream-app Custom INI" }
  ]});
});

app.post("/api/dsapp/start", async (req, res) => {
  const sample = (req.body && req.body.sample) || "test1";
  const uris = (req.body && req.body.uris) || [];
  const image = (req.body && req.body.image) || DS_APP_IMAGE;
  const autoEngine = !!(req.body && req.body.autoEngine);
  if (sample === "app_custom_ini" && autoEngine) {
    try {
      const ini = Array.isArray(uris) && uris.length ? uris[0] : "";
      if (ini && ini.startsWith("/app/configs/")) {
        const hostIni = ini.replace("/app/configs/", "/data/ds/configs/");
        const txt = await fs.promises.readFile(hostIni, "utf8");
        let primaryCfgPath = "";
        const lines = txt.split(/\r?\n/);
        let inPrimary = false;
        for (const l of lines) {
          const s = l.trim();
          if (s.startsWith("[") && s.endsWith("]")) { inPrimary = s.toLowerCase() === "[primary-gie]"; continue; }
          if (inPrimary && s.toLowerCase().startsWith("config-file=")) { primaryCfgPath = s.split("=").slice(1).join("=").trim(); break; }
        }
        if (primaryCfgPath) {
          const resolved = primaryCfgPath.startsWith("/") ? primaryCfgPath.replace("/app/configs/", "/data/ds/configs/") : path.join(path.dirname(hostIni), primaryCfgPath);
          try {
            let cfg = await fs.promises.readFile(resolved, "utf8");
            const hasEngine = /\n\s*model-engine-file\s*=\s*/i.test("\n"+cfg);
            cfg = cfg.split(/\r?\n/).filter(line => !/^\s*model-engine-file\s*=/i.test(line)).join("\n");
            if (!/\n\s*network-mode\s*=\s*/i.test("\n"+cfg)) { cfg += "\nnetwork-mode=1\n"; }
            if (hasEngine) { await fs.promises.writeFile(resolved, cfg, "utf8"); }
          } catch {}
        }
      }
    } catch {}
  }
  const cmd = buildSampleCmd(sample, uris);
  await dockerRequest("DELETE", "/containers/ds_app?force=true");
  const binds = ["/tmp/.X11-unix:/tmp/.X11-unix", "/data/ds/configs:/app/configs", "/data/ds/configs:/data/ds/configs"];
  const env = [
    `DISPLAY=${process.env.DISPLAY || ":0"}`,
    "CUDA_VER=10.2",
    "PLATFORM_TEGRA=1",
    "LD_LIBRARY_PATH=/usr/local/cuda-10.2/lib64:/usr/lib/aarch64-linux-gnu:/usr/lib/arm-linux-gnueabihf"
  ];
  const body = { Image: image, Entrypoint: ["bash"], Cmd: ["-lc", cmd], Env: env, HostConfig: { NetworkMode: "host", Runtime: "nvidia", Binds: binds } };
  let created = await dockerRequest("POST", "/containers/create?name=ds_app", body);
  if (!(created.statusCode >= 200 && created.statusCode < 300)) {
    await dockerRequest("POST", `/images/create?fromImage=${encodeURIComponent(image)}`);
    await dockerRequest("DELETE", "/containers/ds_app?force=true");
    created = await dockerRequest("POST", "/containers/create?name=ds_app", body);
  }
  if (!(created.statusCode >= 200 && created.statusCode < 300)) {
    return res.status(500).json({ ok: false, cmd, image, error: created.body || "create_failed" });
  }
  const start = await dockerRequest("POST", "/containers/ds_app/start");
  if (!(start.statusCode >= 200 && start.statusCode < 300)) {
    return res.status(500).json({ ok: false, cmd, image, error: start.body || "start_failed" });
  }
  res.json({ ok: true, cmd, image });
});

app.post("/api/dsapp/stop", async (_req, res) => {
  await dockerRequest("POST", "/containers/ds_app/stop");
  await dockerRequest("DELETE", "/containers/ds_app?force=true");
  res.json({ ok: true });
});

app.get("/api/dsapp/logs", async (_req, res) => {
  const logs = await dockerRequest("GET", "/containers/ds_app/logs?stdout=1&stderr=1&tail=200");
  res.type("text/plain").send(logs.body || "");
});

app.get("/api/configs/read", async (req, res) => {
  try {
    const p = String(req.query.path || "");
    if (!p || !p.startsWith("/app/configs/") || p.includes("..")) return res.status(400).json({ error: "invalid path" });
    const t = await fs.promises.readFile(p, "utf8");
    res.json({ path: p, content: t });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/configs/save", async (req, res) => {
  try {
    const p = String((req.body && req.body.path) || "");
    const c = String((req.body && req.body.content) || "");
    if (!p || !p.startsWith("/app/configs/") || p.includes("..")) return res.status(400).json({ error: "invalid path" });
    await fs.promises.mkdir(path.dirname(p), { recursive: true });
    await fs.promises.writeFile(p, c, "utf8");
    res.json({ ok: true, path: p, bytes: Buffer.byteLength(c) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/configs/list", async (req, res) => {
  try {
    function pickExistingDir(pref) {
      const candidates = [pref, "/app/configs/", "/data/ds/configs/"];
      for (const c of candidates) { try { if (fs.existsSync(c)) return c; } catch {} }
      return pref;
    }
    const base = pickExistingDir(CONFIGS_DIR);
    let dirParam = String(req.query.dir || base);
    if (!dirParam.startsWith(base) || dirParam.includes("..")) dirParam = base;
    const out = [];
    async function walk(p, depth) {
      const ents = await fs.promises.readdir(p, { withFileTypes: true });
      for (const e of ents) {
        const full = path.join(p, e.name);
        if (e.isDirectory()) { if (depth < 4) { await walk(full, depth + 1); } }
        else { const f = full.toLowerCase(); if (f.endsWith(".ini")) out.push(full); }
      }
    }
    await walk(dirParam, 0);
    out.sort();
    res.json({ dir: dirParam, files: out });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});